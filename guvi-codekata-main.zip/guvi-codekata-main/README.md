# guvi-codekata

Here i post codekata solutions in python3