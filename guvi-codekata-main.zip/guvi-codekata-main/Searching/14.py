n = int(input())
lst = list(map(int,input().split()))
value = max(lst)
print(lst.index(value))