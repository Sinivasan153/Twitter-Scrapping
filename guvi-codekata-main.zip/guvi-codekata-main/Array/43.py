n = int(input())
l = [1]
for i in range(n):
    print(*l)
    l.append(1)
    l.append(1)
