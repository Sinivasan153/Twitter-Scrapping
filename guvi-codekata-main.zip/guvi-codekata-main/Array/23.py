n = int(input())
a = list(map(int,input().split(" ")))
b = [0 for _ in range(n)]
for i in range(n):
    a[i] == a[a[i]]
print(a)