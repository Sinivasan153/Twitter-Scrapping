b = int(input())
a = list(map(str,input().split()))
a.sort()
print(" ".join(a))