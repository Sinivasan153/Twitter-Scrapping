s1,s2 = map(str,input().split())
if s1== s2:
    print('yes')
else:
    print('no')