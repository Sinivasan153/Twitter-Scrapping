n,k = map(int,input().split())
lst = list(map(int,input().split()))
print(*lst[:-k])