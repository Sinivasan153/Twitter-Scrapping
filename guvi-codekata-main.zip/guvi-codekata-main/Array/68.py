lst = list(map(str,input().split()))
print(*lst)