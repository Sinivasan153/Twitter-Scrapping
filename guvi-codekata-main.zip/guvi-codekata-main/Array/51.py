n = int(input())
lst = list(map(int,input().split()))
print(min(lst))