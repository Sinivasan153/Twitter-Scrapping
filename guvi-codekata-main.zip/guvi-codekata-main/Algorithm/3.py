a = list(map(int,input().split()))
b = list(map(int,input().split()))
c = list(map(int,input().split()))
if any(c) == False or any(a) == False or any(b) == False:
    print('yes')
else:
    print('no') 