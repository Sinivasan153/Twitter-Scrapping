n,m = input().split(" ")
n = int(n)
m = int(m)
a = list(map(int,input().split()))
if m in a:
    print('yes')
else:
    print('no')