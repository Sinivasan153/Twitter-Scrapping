n = int(input())
a = list(map(int,input().split(" ")))
print(*a)