n = int(input())
a = list(map(str,input().split(" ")))
a.sort()
print(*a)