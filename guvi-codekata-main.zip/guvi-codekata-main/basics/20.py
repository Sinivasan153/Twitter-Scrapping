n = int(input())
if n % 2 == 0 or n % 3 == 0 or n % 5 == 0:
    print("yes")
else:
    print("no")