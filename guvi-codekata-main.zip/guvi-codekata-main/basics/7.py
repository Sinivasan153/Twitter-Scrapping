a,n = input().split(" ")
a = int(a)
n = int(n)
for i in range(n):
    print(a)