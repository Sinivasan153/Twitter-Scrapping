a = int(input())
for i in range(2,a+1,2):
    print(i)