k,o = input().split()
ans = int(o) - int(k)
print(ans)