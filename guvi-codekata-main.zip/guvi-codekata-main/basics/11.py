n,m = input().split()
answer_1 = int(n) ** 2
answer_2 = int(n)*int(m)
if answer_1 == answer_2:
    print("yes")
else:
    print("no")