a = input()
value = 0
for i in a:
    value += int(i)
print(value)