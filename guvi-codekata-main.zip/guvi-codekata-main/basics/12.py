b,h = input().split()
area = (int(b) * int(h))/2
print(area)