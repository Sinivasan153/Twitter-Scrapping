a = input()
print(*a)