n,m = input().split()
a = int(n)+int(m)
if a % 2 == 0:
    print("even")
else:
    print("odd")