n = input()
k = set()
for i in n:
    k.add(i)
if len(k) == 3:
    print("Wonder")
else:
    print("-1")