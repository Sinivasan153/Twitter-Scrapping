s = input()
s = s[::-1]
print(s.capitalize())