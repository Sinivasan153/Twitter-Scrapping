n,m = input().split()
n = int(n)
m = int(m)
print(n*m)