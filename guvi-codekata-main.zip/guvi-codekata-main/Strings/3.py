a = input()
count = 0
for i in a:
    k = ord(i)
    count += k
print(count)